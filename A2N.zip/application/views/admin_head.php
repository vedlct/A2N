<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">


<title>A2N</title>

<title> A2N </title>


<!-- Bootstrap Core CSS -->
<link href="<?php echo base_url()?>css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url()?>css/modal.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="<?php echo base_url()?>css/sb-admin.css" rel="stylesheet">
<link href="<?php echo base_url()?>css/style2.css" rel="stylesheet">
<link href="<?php echo base_url()?>css/animate.css" rel="stylesheet">

<!-- Custom Fonts -->
<!--<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">-->

<!-- GOOGLE WEB FONT -->
<link href='https://fonts.googleapis.com/css?family=Lato:400,700,900,400italic,700italic,300,300italic' rel='stylesheet' type='text/css'>


<script src="<?php echo base_url()?>js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->

<script src="<?php echo base_url()?>js/cloudfareJquery.js"></script>
<script src="<?php echo base_url()?>js/newbootstrap.js"></script>

<script src="<?php echo base_url()?>js/bootstrap.js"></script>
<script src="<?php echo base_url()?>js/bootstrap.min.js"></script>

<!--[if lt IE 9]>
<script src="<?php echo base_url()?>js/html5shiv.min.js"></script>
<script src="<?php echo base_url()?>js/respond.min.js"></script>
<![endif]-->


<!-- include summernote css/js-->
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.css" rel="stylesheet">
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.2/summernote.js"></script>


